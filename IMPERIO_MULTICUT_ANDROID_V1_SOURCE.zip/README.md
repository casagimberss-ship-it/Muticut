# IMPERIO MULTICUT — Android V1.0

Aplicación Android nativa con Kotlin, Jetpack Compose, SQLite local y selección de hasta seis fuentes de video.

## Funciones incluidas
- Interfaz dark.
- Importación de videos mediante selector del sistema Android.
- Persistencia local de URI, nombre, duración y resolución.
- Listado de fuentes/cámaras.
- Generador inicial de plan de cortes multicámara por alternancia y bloques de 8 segundos.
- Workflow de GitHub Actions para compilar APK debug.

## Estado y limitaciones
Esta entrega es una primera base funcional, no una réplica terminada de Multicut:
- El plan automático todavía no analiza BPM ni detecta drops reales.
- Todavía no sincroniza las grabaciones por huella de audio.
- Todavía no renderiza ni exporta el montaje multicámara final.
- El análisis avanzado y el renderizado son hitos posteriores del motor.

## Requisitos
Android Studio, JDK 17, Android SDK 35 y Gradle 8.9 o compatible.

## Compilar
Abrir el proyecto en Android Studio, sincronizar Gradle y ejecutar `app`.
Para compilar APK: `gradle assembleDebug`.

## GitHub Actions
Subir el proyecto a un repositorio GitHub. El workflow `.github/workflows/android-apk.yml` compila al hacer push a main/master o desde Actions > Build Android APK. Descargar el artefacto `imperio-multicut-debug-apk`.
