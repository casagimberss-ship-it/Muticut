package com.imperio.multicut.data
data class MediaSource(
    val id: Long, val uri: String, val displayName: String, val durationMs: Long,
    val width: Int, val height: Int, val cameraSlot: Int, val importedAt: Long
)
data class CutPoint(val atMs: Long, val cameraSlot: Int, val reason: String)
