package com.imperio.multicut.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class ProjectDatabase(context: Context) : SQLiteOpenHelper(context, "imperio_multicut.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE projects(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, created_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE media(id INTEGER PRIMARY KEY AUTOINCREMENT, uri TEXT NOT NULL, display_name TEXT NOT NULL, duration_ms INTEGER NOT NULL, width INTEGER NOT NULL, height INTEGER NOT NULL, camera_slot INTEGER NOT NULL, imported_at INTEGER NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun ensureProject(name: String): Long {
        readableDatabase.rawQuery("SELECT id FROM projects ORDER BY id LIMIT 1", null).use {
            if (it.moveToFirst()) return it.getLong(0)
        }
        return writableDatabase.insertOrThrow("projects", null, ContentValues().apply {
            put("name", name); put("created_at", System.currentTimeMillis())
        })
    }
    fun addMedia(item: MediaSource): Long = writableDatabase.insertOrThrow("media", null, ContentValues().apply {
        put("uri", item.uri); put("display_name", item.displayName); put("duration_ms", item.durationMs)
        put("width", item.width); put("height", item.height); put("camera_slot", item.cameraSlot)
        put("imported_at", item.importedAt)
    })
    fun listMedia(): List<MediaSource> {
        val result = mutableListOf<MediaSource>()
        readableDatabase.rawQuery("SELECT id,uri,display_name,duration_ms,width,height,camera_slot,imported_at FROM media ORDER BY id", null).use { c ->
            while (c.moveToNext()) result += MediaSource(c.getLong(0), c.getString(1), c.getString(2),
                c.getLong(3), c.getInt(4), c.getInt(5), c.getInt(6), c.getLong(7))
        }
        return result
    }
}
