package com.imperio.multicut.engine

import com.imperio.multicut.data.CutPoint
import com.imperio.multicut.data.MediaSource

/** Creates a first-pass deterministic camera-switch plan. Not yet beat/drop-aware. */
object AutoEditEngine {
    fun createPlan(sources: List<MediaSource>, targetDurationMs: Long? = null): List<CutPoint> {
        val usable = sources.filter { it.durationMs > 0 }.sortedBy { it.cameraSlot }
        if (usable.isEmpty()) return emptyList()
        val total = minOf(targetDurationMs ?: usable.maxOf { it.durationMs }, usable.maxOf { it.durationMs })
        val result = mutableListOf<CutPoint>()
        var t = 0L
        var index = 0
        while (t < total) {
            result += CutPoint(t, usable[index % usable.size].cameraSlot,
                if (t == 0L) "Inicio" else "Cambio automático")
            t += 8_000L
            index++
        }
        return result
    }
}
