package com.imperio.multicut.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf

class AnalysisWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        setProgress(workDataOf("stage" to "Preparando análisis", "progress" to 10))
        return Result.success(workDataOf("status" to "ready_for_audio_analysis"))
    }
}
