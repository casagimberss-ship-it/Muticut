package com.imperio.multicut

import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.imperio.multicut.data.MediaSource
import com.imperio.multicut.data.ProjectDatabase
import com.imperio.multicut.engine.AutoEditEngine
import java.util.concurrent.TimeUnit

private val Bg = Color(0xFF080D16)
private val Panel = Color(0xFF121C2B)
private val Blue = Color(0xFF29B6F6)
private val Muted = Color(0xFF91A0B5)

class MainActivity : ComponentActivity() {
    private lateinit var db: ProjectDatabase
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = ProjectDatabase(this)
        db.ensureProject("Mi primer set")
        setContent { ImperioApp() }
    }

    @Composable
    private fun ImperioApp() {
        var media by remember { mutableStateOf(db.listMedia()) }
        var status by remember { mutableStateOf("Listo para importar hasta 6 cámaras") }
        var planText by remember { mutableStateOf("") }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            uris.forEachIndexed { index, uri -> importUri(uri, index) }
            media = db.listMedia()
            status = "${uris.size} archivo(s) procesado(s)"
        }
        MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Bg, surface = Panel,
            onBackground = Color.White, onSurface = Color.White)) {
            Surface(Modifier.fillMaxSize(), color = Bg) {
                Column(Modifier.fillMaxSize().padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("IMPERIO", color = Blue, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            Text("MULTICUT", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                            Text("DJ AUTOMATIC VIDEO EDITOR", color = Muted, style = MaterialTheme.typography.labelSmall)
                        }
                        Surface(color = Color(0xFF102B40), shape = RoundedCornerShape(14.dp)) {
                            Text("1080p", color = Blue, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp), fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.height(22.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.fillMaxWidth().padding(16.dp)) {
                            Text("PROYECTO ACTIVO", color = Muted, style = MaterialTheme.typography.labelMedium)
                            Text("Mi primer set", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text(status, color = Muted, style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.height(14.dp))
                            Button(onClick = { picker.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Importar videos")
                            }
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("CÁMARAS / FUENTES", modifier = Modifier.weight(1f), color = Color.White, fontWeight = FontWeight.Bold)
                        Text("${media.size}/6", color = Blue, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(8.dp))
                    if (media.isEmpty()) {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Movie, null, tint = Muted, modifier = Modifier.size(34.dp))
                                Text("Todavía no hay videos", color = Muted)
                            }
                        }
                    } else {
                        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(media) { item ->
                                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Movie, null, tint = Blue)
                                        Spacer(Modifier.width(10.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(item.displayName, color = Color.White, maxLines = 1)
                                            Text("Cámara ${item.cameraSlot} • ${item.width}×${item.height} • ${formatDuration(item.durationMs)}",
                                                color = Muted, style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = {
                        val plan = AutoEditEngine.createPlan(media)
                        planText = if (plan.isEmpty()) "Importá al menos un video para generar el plan." else
                            plan.take(12).joinToString("\n") { "${formatDuration(it.atMs)} → Cámara ${it.cameraSlot}: ${it.reason}" }
                        status = "Plan automático generado: ${plan.size} cortes"
                    }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(8.dp)); Text("Generar plan automático")
                    }
                    if (planText.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text("PLAN DE MONTAJE", color = Blue, fontWeight = FontWeight.Bold)
                                Text(planText, color = Color.White, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Procesamiento local • Android • V1.0", color = Muted, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }

    private fun importUri(uri: Uri, index: Int) {
        if (db.listMedia().size >= 6) return
        try { contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        catch (_: Exception) { }
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this, uri)
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val name = uri.lastPathSegment?.substringAfterLast('/') ?: "Video ${index + 1}"
            val slot = (db.listMedia().size + 1).coerceAtMost(6)
            db.addMedia(MediaSource(0, uri.toString(), name, duration, width, height, slot, System.currentTimeMillis()))
        } catch (_: Exception) {
        } finally { retriever.release() }
    }
}

private fun formatDuration(ms: Long): String {
    val seconds = TimeUnit.MILLISECONDS.toSeconds(ms)
    return "%02d:%02d".format(seconds / 60, seconds % 60)
}
